import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { ArrowUpRight, Filter, Search, SlidersHorizontal, X } from 'lucide-react';
import { getListComplaintsQueryKey, useListComplaints } from '@workspace/api-client-react';
import { categoryOptions, priorityOptions, statusOptions, categoryShortName, formatDate, getErrorMessage, sortRecent } from '@/lib/complaints';
import { ComplaintSkeleton, EmptyState, ErrorState, PageHeading, StatusBadge } from '@/components/ui-pieces';

export default function Complaints() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);

  const params = useMemo(() => ({
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(status ? { status: status as never } : {}),
    ...(category ? { category: category as never } : {}),
    ...(priority ? { priority: priority as never } : {}),
  }), [search, status, category, priority]);
  const query = useListComplaints(params, { query: { queryKey: getListComplaintsQueryKey(params) } });
  const complaints = sortRecent(query.data || []);
  const hasFilters = Boolean(search || status || category || priority);

  function clearFilters() {
    setSearch('');
    setStatus('');
    setCategory('');
    setPriority('');
  }

  return (
    <div>
      <PageHeading eyebrow="Complaint register" title="Every report, in one place." description="Search by student, location or issue. Filter the queue to see what needs attention next." />
      <div className="mb-6 rounded-2xl border border-border bg-card p-3 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] md:p-4">
        <div className="flex flex-col gap-3 lg:flex-row">
          <label className="relative flex-1">
            <Search size={17} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} type="search" placeholder="Search complaints..." className="h-11 w-full rounded-xl border border-input bg-background pl-10 pr-4 text-sm outline-none transition-colors placeholder:text-muted-foreground/65 focus:border-primary focus:ring-2 focus:ring-primary/10" data-testid="input-search-complaints" />
          </label>
          <button type="button" onClick={() => setFiltersOpen(!filtersOpen)} className={`inline-flex h-11 items-center justify-center gap-2 rounded-xl border px-4 text-sm font-bold lg:hidden ${filtersOpen ? 'border-primary bg-accent text-accent-foreground' : 'border-input bg-background text-muted-foreground'}`} data-testid="button-toggle-filters"><SlidersHorizontal size={16} /> Filters {(status || category || priority) && <span className="grid h-5 w-5 place-items-center rounded-full bg-primary text-[10px] text-primary-foreground">{[status, category, priority].filter(Boolean).length}</span>}</button>
          <div className={`${filtersOpen ? 'grid' : 'hidden'} grid-cols-1 gap-3 sm:grid-cols-3 lg:grid lg:w-[560px]`}>
            <select value={status} onChange={(event) => setStatus(event.target.value)} className="h-11 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" data-testid="select-filter-status"><option value="">All statuses</option>{statusOptions.map((option) => <option key={option}>{option}</option>)}</select>
            <select value={category} onChange={(event) => setCategory(event.target.value)} className="h-11 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" data-testid="select-filter-category"><option value="">All categories</option>{categoryOptions.map((option) => <option key={option}>{option}</option>)}</select>
            <select value={priority} onChange={(event) => setPriority(event.target.value)} className="h-11 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" data-testid="select-filter-priority"><option value="">All priorities</option>{priorityOptions.map((option) => <option key={option}>{option}</option>)}</select>
          </div>
          {hasFilters && <button type="button" onClick={clearFilters} className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl px-3 text-xs font-bold text-muted-foreground hover:bg-muted hover:text-foreground" data-testid="button-clear-filters"><X size={15} /> Clear</button>}
        </div>
        <div className="mt-3 hidden items-center gap-2 border-t border-border pt-3 lg:flex"><Filter size={14} className="text-muted-foreground" /><span className="text-xs font-bold text-muted-foreground">Narrow by</span><span className="text-xs text-muted-foreground/70">status, category or priority using the controls above</span></div>
      </div>

      {query.isError && <ErrorState message={getErrorMessage(query.error)} onRetry={() => void query.refetch()} />}
      {!query.isError && query.isLoading && <ComplaintSkeleton rows={5} />}
      {!query.isError && !query.isLoading && complaints.length === 0 && <EmptyState title={hasFilters ? 'No matching complaints' : 'The register is clear'} description={hasFilters ? 'Try removing a filter or using a broader search term.' : 'New student reports will appear here as soon as they are submitted.'} action={hasFilters ? <button type="button" onClick={clearFilters} className="mt-5 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground" data-testid="button-empty-clear-filters">Clear filters</button> : <Link href="/complaints/new" className="mt-5 inline-flex rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground" data-testid="link-register-empty-new">Report an issue</Link>} />}
      {!query.isError && !query.isLoading && complaints.length > 0 && (
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)]">
          <div className="flex items-center justify-between border-b border-border px-5 py-4 md:px-6"><p className="text-sm font-bold">{complaints.length} {complaints.length === 1 ? 'complaint' : 'complaints'}</p><p className="text-xs text-muted-foreground">Most recently updated first</p></div>
          <div className="divide-y divide-border">
            {complaints.map((complaint) => (
              <Link href={`/complaints/${complaint.complaintId}`} key={complaint.complaintId} className="group grid gap-3 px-5 py-5 transition-colors hover:bg-muted/45 md:grid-cols-[minmax(180px,1.4fr)_minmax(130px,1fr)_120px_120px_24px] md:items-center md:px-6" data-testid={`row-complaint-${complaint.complaintId}`}>
                <div className="flex min-w-0 items-center gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent font-mono-app text-[10px] font-bold text-accent-foreground">#{String(complaint.complaintId).padStart(3, '0')}</span><span className="min-w-0"><span className="block truncate text-sm font-bold group-hover:text-primary">{complaint.category}</span><span className="mt-1 block truncate text-xs text-muted-foreground">{complaint.description}</span></span></div>
                <div className="pl-[52px] md:pl-0"><p className="truncate text-xs font-semibold text-foreground">{complaint.location}</p><p className="mt-1 text-xs text-muted-foreground">{complaint.studentName} · {formatDate(complaint.createdAt)}</p></div>
                <div className="pl-[52px] md:pl-0"><StatusBadge value={complaint.status} /></div>
                <div className="hidden md:block"><StatusBadge value={complaint.priority} kind="priority" /></div>
                <ArrowUpRight size={16} className="absolute right-5 text-muted-foreground/45 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 md:static" />
                <span className="sr-only">{categoryShortName[complaint.category] || complaint.category}</span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}