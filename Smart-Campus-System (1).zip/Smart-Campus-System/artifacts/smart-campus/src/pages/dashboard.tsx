import { Link } from 'wouter';
import { ArrowUpRight, CheckCircle2, Clock3, Flag, Inbox, Plus, Wrench } from 'lucide-react';
import { useGetComplaintSummary, useListComplaints, getGetComplaintSummaryQueryKey, getListComplaintsQueryKey } from '@workspace/api-client-react';
import { PageHeading, ComplaintSkeleton, ErrorState, EmptyState, StatusBadge } from '@/components/ui-pieces';
import { formatDate, getErrorMessage, sortRecent } from '@/lib/complaints';

function StatCard({ label, value, detail, icon: Icon, tone }: { label: string; value: number | string; detail: string; icon: typeof Inbox; tone: string }) {
  return (
    <div className="group rounded-2xl border border-border bg-card p-5 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] transition-transform hover:-translate-y-1" data-testid={`stat-card-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div className="flex items-start justify-between"><span className={`grid h-10 w-10 place-items-center rounded-xl ${tone}`}><Icon size={19} /></span><ArrowUpRight size={16} className="text-muted-foreground/50 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></div>
      <p className="mt-5 font-mono-app text-3xl font-bold tracking-tight" data-testid={`text-stat-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</p>
      <p className="mt-1 text-sm font-bold">{label}</p>
      <p className="mt-1 text-xs text-muted-foreground">{detail}</p>
    </div>
  );
}

export default function Dashboard() {
  const summaryQuery = useGetComplaintSummary({ query: { queryKey: getGetComplaintSummaryQueryKey() } });
  const recentQuery = useListComplaints(undefined, { query: { queryKey: getListComplaintsQueryKey() } });
  const summary = summaryQuery.data;
  const complaints = sortRecent(recentQuery.data || []).slice(0, 5);

  return (
    <div>
      <PageHeading
        eyebrow="Tuesday, campus service desk"
        title="Make campus work better."
        description="One place to report what is getting in the way, and see what is being done about it."
        action={<Link href="/complaints/new" className="inline-flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-sm font-bold text-secondary-foreground shadow-[0_8px_20px_hsl(39_89%_64%_/_0.18)] transition-transform hover:-translate-y-0.5" data-testid="link-dashboard-new"><Plus size={17} /> Report an issue</Link>}
      />

      {(summaryQuery.isError || recentQuery.isError) && (
        <ErrorState message={getErrorMessage(summaryQuery.error || recentQuery.error)} onRetry={() => { void summaryQuery.refetch(); void recentQuery.refetch(); }} />
      )}

      {!summaryQuery.isError && (
        <>
          <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
            <StatCard label="Total reports" value={summaryQuery.isLoading ? '—' : summary?.total ?? 0} detail="All time on record" icon={Inbox} tone="bg-accent text-accent-foreground" />
            <StatCard label="Awaiting review" value={summaryQuery.isLoading ? '—' : summary?.pending ?? 0} detail="Needs a first look" icon={Clock3} tone="bg-amber-50 text-amber-700" />
            <StatCard label="In progress" value={summaryQuery.isLoading ? '—' : summary?.inProgress ?? 0} detail="Being worked on now" icon={Wrench} tone="bg-sky-50 text-sky-700" />
            <StatCard label="Resolved" value={summaryQuery.isLoading ? '—' : summary?.resolved ?? 0} detail="Closed successfully" icon={CheckCircle2} tone="bg-emerald-50 text-emerald-700" />
            <StatCard label="High priority" value={summaryQuery.isLoading ? '—' : summary?.highPriority ?? 0} detail="Needs attention first" icon={Flag} tone="bg-rose-50 text-rose-700" />
          </section>

          <section className="mt-10 grid gap-6 xl:grid-cols-[1.4fr_0.6fr]">
            <div className="rounded-2xl border border-border bg-card p-5 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] md:p-7">
              <div className="mb-6 flex items-end justify-between gap-3">
                <div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[0.16em] text-accent-foreground">Live register</p><h2 className="mt-1 font-display text-xl font-bold">Recent complaints</h2></div>
                <Link href="/complaints" className="text-xs font-bold text-primary hover:underline" data-testid="link-view-all-complaints">View all <span aria-hidden="true">→</span></Link>
              </div>
              {recentQuery.isLoading ? <ComplaintSkeleton rows={3} /> : complaints.length === 0 ? (
                <EmptyState title="No complaints yet" description="When a student reports an issue, it will appear here." action={<Link href="/complaints/new" className="mt-5 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground" data-testid="link-empty-new"><Plus size={15} /> Report the first issue</Link>} />
              ) : (
                <div className="divide-y divide-border">
                  {complaints.map((complaint, index) => (
                    <Link key={complaint.complaintId} href={`/complaints/${complaint.complaintId}`} className={`group flex items-center gap-3 py-4 first:pt-0 last:pb-0 ${index > 2 ? 'hidden sm:flex' : ''}`} data-testid={`link-recent-complaint-${complaint.complaintId}`}>
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-muted font-mono-app text-[10px] font-bold text-muted-foreground">#{String(complaint.complaintId).padStart(3, '0')}</span>
                      <span className="min-w-0 flex-1"><span className="block truncate text-sm font-bold group-hover:text-primary">{complaint.category}</span><span className="mt-1 block truncate text-xs text-muted-foreground">{complaint.location} · {formatDate(complaint.createdAt)}</span></span>
                      <StatusBadge value={complaint.status} />
                      <ArrowUpRight size={16} className="hidden text-muted-foreground/50 sm:block" />
                    </Link>
                  ))}
                </div>
              )}
            </div>
            <div className="relative overflow-hidden rounded-2xl bg-primary p-6 text-primary-foreground md:p-7">
              <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full border-[22px] border-secondary/25" />
              <div className="absolute -bottom-24 -left-12 h-44 w-44 rounded-full border-[18px] border-primary-foreground/10" />
              <div className="relative">
                <p className="font-mono-app text-[10px] font-bold uppercase tracking-[0.16em] text-secondary">Your report matters</p>
                <h2 className="mt-4 max-w-[280px] font-display text-2xl font-extrabold leading-tight">Small fixes make a better day for everyone.</h2>
                <p className="mt-4 text-sm leading-6 text-primary-foreground/70">Notice a broken light, a leaky tap or a network dead zone? Tell us while it is fresh.</p>
                <Link href="/complaints/new" className="mt-8 inline-flex items-center gap-2 rounded-lg bg-secondary px-4 py-3 text-xs font-bold text-secondary-foreground hover:bg-secondary/90" data-testid="link-card-new"><Plus size={15} /> Start a report</Link>
              </div>
            </div>
          </section>
        </>
      )}
    </div>
  );
}