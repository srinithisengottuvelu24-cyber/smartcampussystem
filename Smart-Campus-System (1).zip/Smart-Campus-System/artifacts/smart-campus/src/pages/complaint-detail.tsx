import { useState } from 'react';
import { Link, useLocation, useRoute } from 'wouter';
import { ArrowUpRight, CalendarDays, Clipboard, Edit3, MapPin, MessageSquare, Shield, Trash2, UserRound } from 'lucide-react';
import { getGetComplaintQueryKey, getListComplaintsQueryKey, getGetComplaintSummaryQueryKey, useDeleteComplaint, useGetComplaint } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { BackLink, ComplaintSkeleton, ErrorState, StatusBadge } from '@/components/ui-pieces';
import { formatDateTime, getErrorMessage, getInitials } from '@/lib/complaints';

export default function ComplaintDetail() {
  const [, params] = useRoute('/complaints/:id');
  const [, setLocation] = useLocation();
  const id = Number(params?.id);
  const queryClient = useQueryClient();
  const query = useGetComplaint(id, { query: { enabled: Number.isFinite(id), queryKey: getGetComplaintQueryKey(id) } });
  const deleteMutation = useDeleteComplaint();
  const [deleteOpen, setDeleteOpen] = useState(false);

  function deleteComplaint() {
    deleteMutation.mutate({ id }, {
      onSuccess: () => {
        void queryClient.invalidateQueries({ queryKey: getListComplaintsQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetComplaintSummaryQueryKey() });
        setLocation('/complaints');
      },
    });
  }

  if (query.isLoading) return <ComplaintSkeleton rows={3} />;
  if (query.isError || !query.data) return <ErrorState message={getErrorMessage(query.error, 'This complaint could not be found.')} onRetry={() => void query.refetch()} />;
  const complaint = query.data;

  return (
    <div className="mx-auto max-w-[1040px]">
      <BackLink href="/complaints">Back to complaint register</BackLink>
      <div className="mb-7 flex flex-col justify-between gap-5 md:flex-row md:items-end">
        <div>
          <div className="mb-3 flex flex-wrap items-center gap-2"><span className="font-mono-app text-xs font-bold text-muted-foreground">COMPLAINT #{String(complaint.complaintId).padStart(3, '0')}</span><StatusBadge value={complaint.status} /><StatusBadge value={complaint.priority} kind="priority" /></div>
          <h1 className="max-w-[720px] font-display text-3xl font-extrabold tracking-[-0.035em] md:text-[42px] md:leading-[1.06]" data-testid="heading-complaint-title">{complaint.category} issue at {complaint.location}</h1>
          <p className="mt-3 text-sm text-muted-foreground">Reported {formatDateTime(complaint.createdAt)} · Updated {formatDateTime(complaint.updatedAt)}</p>
        </div>
        <div className="flex gap-2">
          <Link href={`/complaints/${complaint.complaintId}/edit`} className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-bold hover:bg-muted" data-testid="link-edit-complaint"><Edit3 size={15} /> Edit</Link>
          <button type="button" onClick={() => setDeleteOpen(true)} className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm font-bold text-rose-700 hover:bg-rose-100" data-testid="button-delete-complaint"><Trash2 size={15} /> Delete</button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.35fr_0.65fr]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-border bg-card p-6 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] md:p-8" data-testid="card-complaint-description">
            <div className="mb-5 flex items-center gap-2"><MessageSquare size={17} className="text-accent-foreground" /><h2 className="font-display text-lg font-bold">What was reported</h2></div>
            <p className="whitespace-pre-wrap text-sm leading-7 text-foreground/80">{complaint.description}</p>
            {complaint.resolutionRemarks && <div className="mt-7 border-t border-border pt-6"><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.15em] text-muted-foreground">Service desk remarks</p><p className="whitespace-pre-wrap text-sm leading-7 text-foreground/80">{complaint.resolutionRemarks}</p></div>}
          </section>
          <section className="rounded-2xl border border-border bg-card p-6 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] md:p-8">
            <div className="mb-5 flex items-center justify-between"><div className="flex items-center gap-2"><Clipboard size={17} className="text-accent-foreground" /><h2 className="font-display text-lg font-bold">Activity</h2></div><span className="text-xs font-semibold text-muted-foreground">{complaint.status}</span></div>
            <div className="relative ml-2 border-l border-border pl-6"><span className="absolute -left-[7px] top-1 h-3 w-3 rounded-full border-2 border-card bg-secondary ring-1 ring-secondary/30" /><p className="text-sm font-bold">Complaint submitted</p><p className="mt-1 text-xs text-muted-foreground">{formatDateTime(complaint.createdAt)}</p><span className="absolute -left-[7px] top-[72px] h-3 w-3 rounded-full border-2 border-card bg-accent-foreground ring-1 ring-accent-foreground/20" /><p className="mt-10 text-sm font-bold">{complaint.status === 'Pending' ? 'Waiting for service desk review' : `Status is ${complaint.status.toLowerCase()}`}</p><p className="mt-1 text-xs text-muted-foreground">{formatDateTime(complaint.updatedAt)}</p></div>
          </section>
        </div>
        <aside className="space-y-6">
          <section className="rounded-2xl border border-border bg-card p-6 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)]">
            <h2 className="mb-5 font-display text-lg font-bold">Report details</h2>
            <dl className="space-y-4">
              <div className="flex gap-3"><MapPin size={16} className="mt-0.5 shrink-0 text-muted-foreground" /><span><dt className="text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Location</dt><dd className="mt-1 text-sm font-semibold">{complaint.location}</dd></span></div>
              <div className="flex gap-3"><UserRound size={16} className="mt-0.5 shrink-0 text-muted-foreground" /><span><dt className="text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Reported by</dt><dd className="mt-1 text-sm font-semibold">{complaint.studentName}</dd><dd className="mt-0.5 text-xs text-muted-foreground">{complaint.studentId} · {complaint.department}</dd></span></div>
              <div className="flex gap-3"><CalendarDays size={16} className="mt-0.5 shrink-0 text-muted-foreground" /><span><dt className="text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Last updated</dt><dd className="mt-1 text-sm font-semibold">{formatDateTime(complaint.updatedAt)}</dd></span></div>
              <div className="flex gap-3"><Shield size={16} className="mt-0.5 shrink-0 text-muted-foreground" /><span><dt className="text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Assigned staff</dt><dd className="mt-1 text-sm font-semibold">{complaint.assignedStaff || 'Awaiting assignment'}</dd></span></div>
            </dl>
          </section>
          <div className="rounded-2xl bg-accent p-6"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-card text-accent-foreground"><span className="font-mono-app text-xs font-bold">{getInitials(complaint.studentName)}</span></span><div><p className="text-xs font-bold">Keep an eye on this report</p><p className="mt-1 text-xs leading-5 text-muted-foreground">The service desk updates the status as work progresses.</p></div></div><Link href="/complaints" className="mt-5 inline-flex items-center gap-1 text-xs font-bold text-accent-foreground hover:underline" data-testid="link-detail-register">Back to register <ArrowUpRight size={13} /></Link></div>
        </aside>
      </div>

      {deleteOpen && <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/35 p-5" role="dialog" aria-modal="true" data-testid="dialog-delete-confirmation"><div className="w-full max-w-md rounded-2xl bg-card p-6 shadow-2xl"><h2 className="font-display text-xl font-bold">Delete this complaint?</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">This will permanently remove complaint #{String(complaint.complaintId).padStart(3, '0')} from the register. This cannot be undone.</p>{deleteMutation.isError && <p className="mt-3 rounded-lg bg-rose-50 p-3 text-xs font-semibold text-rose-700">{getErrorMessage(deleteMutation.error)}</p>}<div className="mt-6 flex justify-end gap-3"><button type="button" onClick={() => setDeleteOpen(false)} className="rounded-lg px-4 py-2.5 text-sm font-bold text-muted-foreground hover:bg-muted" data-testid="button-cancel-delete">Cancel</button><button type="button" onClick={deleteComplaint} disabled={deleteMutation.isPending} className="rounded-lg bg-destructive px-4 py-2.5 text-sm font-bold text-destructive-foreground disabled:opacity-60" data-testid="button-confirm-delete">{deleteMutation.isPending ? 'Deleting...' : 'Delete complaint'}</button></div></div></div>}
    </div>
  );
}