import {
  ComplaintCategory,
  ComplaintPriority,
  ComplaintStatus,
  type Complaint,
} from '@workspace/api-client-react';

export const categoryOptions = Object.values(ComplaintCategory);
export const priorityOptions = Object.values(ComplaintPriority);
export const statusOptions = Object.values(ComplaintStatus);

export const categoryShortName: Record<string, string> = {
  'Internet/Network': 'Network',
};

export const statusTone: Record<string, string> = {
  Pending: 'bg-amber-50 text-amber-800 border-amber-200',
  'In Progress': 'bg-sky-50 text-sky-800 border-sky-200',
  Resolved: 'bg-emerald-50 text-emerald-800 border-emerald-200',
  Rejected: 'bg-rose-50 text-rose-800 border-rose-200',
};

export const priorityTone: Record<string, string> = {
  Low: 'bg-slate-100 text-slate-600 border-slate-200',
  Medium: 'bg-teal-50 text-teal-800 border-teal-200',
  High: 'bg-orange-50 text-orange-800 border-orange-200',
  Urgent: 'bg-rose-50 text-rose-800 border-rose-200',
};

export function formatDate(value?: string | null) {
  if (!value) return 'Not available';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export function formatDateTime(value?: string | null) {
  if (!value) return 'Not available';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

export function getInitials(name?: string | null) {
  return (name || 'Student')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toUpperCase();
}

export function getErrorMessage(error: unknown, fallback = 'Something went wrong. Please try again.') {
  if (error && typeof error === 'object' && 'error' in error && typeof error.error === 'string') {
    return error.error;
  }
  if (error instanceof Error && error.message) return error.message;
  return fallback;
}

export function sortRecent(complaints: Complaint[]) {
  return [...complaints].sort(
    (a, b) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime(),
  );
}