import { type ReactNode } from 'react';
import { AlertCircle, ArrowLeft, Inbox, RefreshCw } from 'lucide-react';
import { Link } from 'wouter';
import { priorityTone, statusTone } from '@/lib/complaints';

export function StatusBadge({ value, kind = 'status' }: { value: string; kind?: 'status' | 'priority' }) {
  const tone = kind === 'priority' ? priorityTone[value] : statusTone[value];
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-bold ${tone || 'border-border bg-muted text-muted-foreground'}`}
      data-testid={`${kind}-badge-${value.toLowerCase().replaceAll(' ', '-')}`}
    >
      {value}
    </span>
  );
}

export function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
      <div>
        {eyebrow && <p className="mb-2 font-mono-app text-[10px] font-bold uppercase tracking-[0.18em] text-accent-foreground">{eyebrow}</p>}
        <h1 className="font-display text-3xl font-extrabold tracking-[-0.035em] text-foreground md:text-[42px] md:leading-[1.05]" data-testid="heading-page-title">{title}</h1>
        {description && <p className="mt-3 max-w-[600px] text-sm leading-6 text-muted-foreground" data-testid="text-page-description">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-2xl border border-rose-200 bg-rose-50/70 p-8 text-center" role="alert" data-testid="state-error">
      <span className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-rose-100 text-rose-700"><AlertCircle size={20} /></span>
      <h2 className="mt-4 font-display text-lg font-bold text-rose-950">We could not load this view</h2>
      <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-rose-800/75">{message}</p>
      {onRetry && (
        <button type="button" onClick={onRetry} className="mt-5 inline-flex items-center gap-2 rounded-lg border border-rose-200 bg-white px-4 py-2.5 text-sm font-bold text-rose-800 hover:bg-rose-100" data-testid="button-retry">
          <RefreshCw size={15} /> Try again
        </button>
      )}
    </div>
  );
}

export function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-border bg-card px-6 py-14 text-center" data-testid="state-empty">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-accent text-accent-foreground"><Inbox size={21} /></span>
      <h2 className="mt-4 font-display text-lg font-bold">{title}</h2>
      <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">{description}</p>
      {action}
    </div>
  );
}

export function ComplaintSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3" aria-label="Loading complaints" data-testid="state-loading">
      {Array.from({ length: rows }).map((_, index) => (
        <div key={index} className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5">
          <div className="skeleton-shimmer h-10 w-10 rounded-xl" />
          <div className="flex-1 space-y-2"><div className="skeleton-shimmer h-3 w-1/3 rounded" /><div className="skeleton-shimmer h-3 w-2/3 rounded" /></div>
          <div className="skeleton-shimmer hidden h-6 w-20 rounded-full sm:block" />
        </div>
      ))}
    </div>
  );
}

export function BackLink({ href, children }: { href: string; children: ReactNode }) {
  return <Link href={href} className="mb-6 inline-flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-primary" data-testid="link-back"><ArrowLeft size={15} />{children}</Link>;
}