import { Link, useLocation, useRoute } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { getGetComplaintQueryKey, getGetComplaintSummaryQueryKey, getListComplaintsQueryKey, useGetComplaint, useUpdateComplaint } from '@workspace/api-client-react';
import type { ComplaintUpdate } from '@workspace/api-client-react';
import { ComplaintForm } from '@/components/complaint-form';
import { BackLink, ComplaintSkeleton, ErrorState, PageHeading } from '@/components/ui-pieces';
import { getErrorMessage } from '@/lib/complaints';

export default function EditComplaint() {
  const [, params] = useRoute('/complaints/:id/edit');
  const [, setLocation] = useLocation();
  const id = Number(params?.id);
  const queryClient = useQueryClient();
  const query = useGetComplaint(id, { query: { enabled: Number.isFinite(id), queryKey: getGetComplaintQueryKey(id) } });
  const updateMutation = useUpdateComplaint();

  function submit(values: ComplaintUpdate) {
    updateMutation.mutate({ id, data: values }, {
      onSuccess: () => {
        void queryClient.invalidateQueries({ queryKey: getGetComplaintQueryKey(id) });
        void queryClient.invalidateQueries({ queryKey: getListComplaintsQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetComplaintSummaryQueryKey() });
        setLocation(`/complaints/${id}`);
      },
    });
  }

  if (query.isLoading) return <ComplaintSkeleton rows={3} />;
  if (query.isError || !query.data) return <ErrorState message={getErrorMessage(query.error, 'This complaint could not be found.')} onRetry={() => void query.refetch()} />;

  return (
    <div className="mx-auto max-w-[920px]">
      <BackLink href={`/complaints/${id}`}>Back to complaint</BackLink>
      <PageHeading eyebrow={`Editing complaint #${String(id).padStart(3, '0')}`} title="Update the service record." description="Keep the report details accurate and add the latest service desk context for everyone following along." />
      {updateMutation.isError && <div className="mb-6"><ErrorState message={getErrorMessage(updateMutation.error)} /></div>}
      <ComplaintForm mode="edit" initial={query.data} onSubmit={(values) => submit(values as ComplaintUpdate)} isPending={updateMutation.isPending} />
      <div className="mt-5 text-center"><Link href={`/complaints/${id}`} className="text-xs font-bold text-muted-foreground hover:text-primary" data-testid="link-edit-cancel">Cancel and return to complaint</Link></div>
    </div>
  );
}