import { useEffect, type ReactNode } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { MapPin, Send, UserRound } from 'lucide-react';
import {
  ComplaintCategory,
  ComplaintPriority,
  ComplaintStatus,
  type Complaint,
  type ComplaintInput,
  type ComplaintUpdate,
} from '@workspace/api-client-react';
import { categoryOptions, priorityOptions, statusOptions } from '@/lib/complaints';

const complaintSchema = z.object({
  studentName: z.string().trim().min(2, 'Enter the student name.'),
  studentId: z.string().trim().min(2, 'Enter a valid student ID.'),
  department: z.string().trim().min(2, 'Enter the department.'),
  category: z.enum(categoryOptions as [string, ...string[]]),
  location: z.string().trim().min(2, 'Tell us where the issue is.'),
  description: z.string().trim().min(10, 'Add at least 10 characters so the team can act.'),
  priority: z.enum(priorityOptions as [string, ...string[]]),
  status: z.enum(statusOptions as [string, ...string[]]).optional(),
  assignedStaff: z.string().optional(),
  resolutionRemarks: z.string().optional(),
});

type FormValues = z.infer<typeof complaintSchema>;

type ComplaintFormProps = {
  mode: 'create' | 'edit';
  initial?: Complaint;
  onSubmit: (values: ComplaintInput | ComplaintUpdate) => void;
  isPending?: boolean;
};

function Field({
  label,
  name,
  error,
  children,
  hint,
}: {
  label: string;
  name: string;
  error?: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-2 block text-xs font-bold text-foreground">{label}</label>
      {children}
      {hint && !error && <p className="mt-1.5 text-[11px] text-muted-foreground">{hint}</p>}
      {error && <p className="mt-1.5 text-[11px] font-semibold text-destructive">{error}</p>}
    </div>
  );
}

const inputClass = 'w-full rounded-xl border border-input bg-background px-3.5 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/10';

export function ComplaintForm({ mode, initial, onSubmit, isPending = false }: ComplaintFormProps) {
  const form = useForm<FormValues>({
    resolver: zodResolver(complaintSchema),
    defaultValues: {
      studentName: initial?.studentName || '',
      studentId: initial?.studentId || '',
      department: initial?.department || '',
      category: initial?.category || ComplaintCategory.Other,
      location: initial?.location || '',
      description: initial?.description || '',
      priority: initial?.priority || ComplaintPriority.Medium,
      status: initial?.status || ComplaintStatus.Pending,
      assignedStaff: initial?.assignedStaff || '',
      resolutionRemarks: initial?.resolutionRemarks || '',
    },
  });

  useEffect(() => {
    if (!initial) return;
    form.reset({
      studentName: initial.studentName,
      studentId: initial.studentId,
      department: initial.department,
      category: initial.category,
      location: initial.location,
      description: initial.description,
      priority: initial.priority,
      status: initial.status,
      assignedStaff: initial.assignedStaff || '',
      resolutionRemarks: initial.resolutionRemarks || '',
    });
  }, [initial, form]);

  const errors = form.formState.errors;

  return (
    <form onSubmit={form.handleSubmit((values) => onSubmit(values as ComplaintInput | ComplaintUpdate))} className="space-y-7" noValidate>
      <section className="rounded-2xl border border-border bg-card p-5 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] md:p-7">
        <div className="mb-6 flex items-start gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground"><UserRound size={17} /></span>
          <div><h2 className="font-display text-lg font-bold">About you</h2><p className="mt-1 text-xs text-muted-foreground">So the right team can follow up with you.</p></div>
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          <Field label="Student name" name="studentName" error={errors.studentName?.message as string}>
            <input id="studentName" {...form.register('studentName')} className={inputClass} placeholder="e.g. Aanya Rao" data-testid="input-student-name" />
          </Field>
          <Field label="Student ID" name="studentId" error={errors.studentId?.message as string}>
            <input id="studentId" {...form.register('studentId')} className={inputClass} placeholder="e.g. 23CS041" data-testid="input-student-id" />
          </Field>
          <Field label="Department" name="department" error={errors.department?.message as string} hint="Your academic department or programme.">
            <input id="department" {...form.register('department')} className={inputClass} placeholder="e.g. Computer Science" data-testid="input-department" />
          </Field>
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] md:p-7">
        <div className="mb-6 flex items-start gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground"><MapPin size={17} /></span>
          <div><h2 className="font-display text-lg font-bold">Issue details</h2><p className="mt-1 text-xs text-muted-foreground">A clear report helps facilities teams arrive prepared.</p></div>
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          <Field label="Category" name="category" error={errors.category?.message as string}>
            <select id="category" {...form.register('category')} className={inputClass} data-testid="select-category">
              {categoryOptions.map((option) => <option key={option} value={option}>{option}</option>)}
            </select>
          </Field>
          <Field label="Priority" name="priority" error={errors.priority?.message as string} hint="Urgent is for safety risks or issues blocking an essential service.">
            <select id="priority" {...form.register('priority')} className={inputClass} data-testid="select-priority">
              {priorityOptions.map((option) => <option key={option} value={option}>{option}</option>)}
            </select>
          </Field>
          <div className="md:col-span-2">
            <Field label="Where is the issue?" name="location" error={errors.location?.message as string}>
              <input id="location" {...form.register('location')} className={inputClass} placeholder="e.g. Block C, 2nd floor, Room 204" data-testid="input-location" />
            </Field>
          </div>
          <div className="md:col-span-2">
            <Field label="What is happening?" name="description" error={errors.description?.message as string} hint="Include what you noticed and when it started.">
              <textarea id="description" {...form.register('description')} className={`${inputClass} min-h-[130px] resize-y`} placeholder="Describe the issue in a few sentences..." data-testid="textarea-description" />
            </Field>
          </div>
        </div>
      </section>

      {mode === 'edit' && (
        <section className="rounded-2xl border border-border bg-card p-5 shadow-[0_8px_24px_hsl(207_46%_18%_/_0.035)] md:p-7">
          <div className="mb-6"><h2 className="font-display text-lg font-bold">Service desk update</h2><p className="mt-1 text-xs text-muted-foreground">Visible to the student and campus service teams.</p></div>
          <div className="grid gap-5 md:grid-cols-2">
            <Field label="Status" name="status" error={errors.status?.message as string}>
              <select id="status" {...form.register('status')} className={inputClass} data-testid="select-status">
                {statusOptions.map((option) => <option key={option} value={option}>{option}</option>)}
              </select>
            </Field>
            <Field label="Assigned staff" name="assignedStaff" hint="Optional">
              <input id="assignedStaff" {...form.register('assignedStaff')} className={inputClass} placeholder="e.g. Facilities — R. Menon" data-testid="input-assigned-staff" />
            </Field>
            <div className="md:col-span-2">
              <Field label="Resolution remarks" name="resolutionRemarks" hint="Add a short note when the status changes.">
                <textarea id="resolutionRemarks" {...form.register('resolutionRemarks')} className={`${inputClass} min-h-[110px] resize-y`} placeholder="What was done, or what happens next?" data-testid="textarea-resolution-remarks" />
              </Field>
            </div>
          </div>
        </section>
      )}

      <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-end">
        <button type="button" onClick={() => window.history.back()} className="rounded-xl px-5 py-3 text-sm font-bold text-muted-foreground hover:bg-muted hover:text-foreground" data-testid="button-cancel-form">Cancel</button>
        <button type="submit" disabled={isPending} className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-[0_8px_18px_hsl(207_65%_31%_/_0.18)] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60" data-testid="button-submit-complaint">
          <Send size={16} />{isPending ? 'Saving...' : mode === 'create' ? 'Submit complaint' : 'Save updates'}
        </button>
      </div>
    </form>
  );
}