import { useState, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import {
  Bell,
  ChevronRight,
  ClipboardList,
  LayoutDashboard,
  Menu,
  Plus,
  X,
} from 'lucide-react';

type LayoutProps = {
  children: ReactNode;
};

const navItems = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/complaints', label: 'Complaint register', icon: ClipboardList },
];

export function AppLayout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="campus-noise min-h-[100dvh] bg-background text-foreground">
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[256px] flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300 md:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between px-6 pb-6 pt-7">
          <Link href="/" className="flex items-center gap-3" data-testid="link-brand">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-secondary-foreground shadow-sm">
              <span className="font-display text-xl font-extrabold">S</span>
            </span>
            <span>
              <span className="block font-display text-[17px] font-extrabold tracking-tight">Smart Campus</span>
              <span className="block text-[10px] font-semibold uppercase tracking-[0.18em] text-sidebar-foreground/55">service desk</span>
            </span>
          </Link>
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            className="rounded-lg p-2 text-sidebar-foreground/65 hover:bg-sidebar-accent md:hidden"
            aria-label="Close navigation"
            data-testid="button-close-navigation"
          >
            <X size={18} />
          </button>
        </div>

        <div className="px-4">
          <Link
            href="/complaints/new"
            onClick={() => setMobileOpen(false)}
            className="flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-sm font-bold text-secondary-foreground shadow-[0_8px_20px_hsl(39_89%_64%_/_0.16)] transition-transform hover:-translate-y-0.5"
            data-testid="link-new-complaint"
          >
            <Plus size={17} strokeWidth={2.5} />
            Report an issue
          </Link>
        </div>

        <nav className="mt-8 flex-1 px-3" aria-label="Main navigation">
          <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-sidebar-foreground/40">Workspace</p>
          {navItems.map((item) => {
            const active = item.href === '/' ? location === '/' : location.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={`mb-1 flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors ${
                  active ? 'bg-sidebar-accent text-sidebar-foreground' : 'text-sidebar-foreground/62 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'
                }`}
                data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}
              >
                <Icon size={18} className={active ? 'text-secondary' : ''} />
                {item.label}
                {active && <ChevronRight size={15} className="ml-auto text-sidebar-foreground/45" />}
              </Link>
            );
          })}
        </nav>

        <div className="mx-4 mb-5 rounded-2xl border border-sidebar-border bg-sidebar-accent/55 p-4">
          <div className="mb-3 flex items-center gap-2 text-secondary">
            <Bell size={16} />
            <span className="text-[11px] font-bold uppercase tracking-[0.12em]">Good to know</span>
          </div>
          <p className="text-xs leading-5 text-sidebar-foreground/68">Clear details and a precise location help campus teams resolve issues faster.</p>
        </div>
        <div className="border-t border-sidebar-border px-6 py-4 text-[11px] text-sidebar-foreground/40">Built for a better campus day</div>
      </aside>

      {mobileOpen && (
        <button
          type="button"
          aria-label="Close navigation overlay"
          className="fixed inset-0 z-30 bg-slate-950/35 md:hidden"
          onClick={() => setMobileOpen(false)}
          data-testid="button-navigation-overlay"
        />
      )}

      <div className="min-h-[100dvh] md:pl-[256px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-border/80 bg-background/90 px-5 backdrop-blur-md md:px-10">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="rounded-lg p-2 text-muted-foreground hover:bg-muted md:hidden"
              aria-label="Open navigation"
              data-testid="button-open-navigation"
            >
              <Menu size={20} />
            </button>
            <div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex">
              <span>Campus services</span><ChevronRight size={13} /><span className="font-semibold text-foreground">Complaints</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs font-medium text-muted-foreground sm:inline">Need something fixed?</span>
            <Link
              href="/complaints/new"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-3.5 py-2 text-xs font-bold text-primary-foreground transition-colors hover:bg-primary/90"
              data-testid="link-header-new-complaint"
            >
              <Plus size={15} />
              New complaint
            </Link>
          </div>
        </header>
        <main className="page-enter mx-auto max-w-[1440px] px-5 py-7 md:px-10 md:py-10">{children}</main>
      </div>
    </div>
  );
}