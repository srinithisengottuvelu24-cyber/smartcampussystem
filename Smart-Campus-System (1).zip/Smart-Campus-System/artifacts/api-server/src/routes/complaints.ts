import { and, desc, eq, ilike, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateComplaintBody,
  DeleteComplaintParams,
  GetComplaintParams,
  GetComplaintResponse,
  GetComplaintSummaryResponse,
  ListComplaintsQueryParams,
  ListComplaintsResponse,
  UpdateComplaintBody,
  UpdateComplaintParams,
  UpdateComplaintResponse,
} from "@workspace/api-zod";
import {
  complaintCategories,
  complaintPriorities,
  complaintStatuses,
  complaintsTable,
  db,
} from "@workspace/db";

const router: IRouter = Router();

const statusValues = new Set<string>(complaintStatuses);
const categoryValues = new Set<string>(complaintCategories);
const priorityValues = new Set<string>(complaintPriorities);

function cleanNullable(value: string | null | undefined): string | null {
  if (value == null) return null;
  const trimmed = value.trim();
  return trimmed.length ? trimmed : null;
}

router.get("/complaints/summary", async (_req, res): Promise<void> => {
  const complaints = await db.select().from(complaintsTable);
  const summary = {
    total: complaints.length,
    pending: complaints.filter((item) => item.status === "Pending").length,
    inProgress: complaints.filter((item) => item.status === "In Progress").length,
    resolved: complaints.filter((item) => item.status === "Resolved").length,
    highPriority: complaints.filter(
      (item) => item.priority === "High" || item.priority === "Urgent",
    ).length,
  };
  res.json(GetComplaintSummaryResponse.parse(summary));
});

router.get("/complaints", async (req, res): Promise<void> => {
  const parsed = ListComplaintsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { search, status, category, priority, department } = parsed.data;
  const filters = [];

  if (search?.trim()) {
    const term = `%${search.trim()}%`;
    filters.push(
      or(
        ilike(complaintsTable.studentName, term),
        ilike(complaintsTable.studentId, term),
        ilike(complaintsTable.location, term),
        ilike(complaintsTable.description, term),
      ),
    );
  }
  if (status && statusValues.has(status)) {
    filters.push(eq(complaintsTable.status, status));
  }
  if (category && categoryValues.has(category)) {
    filters.push(eq(complaintsTable.category, category));
  }
  if (priority && priorityValues.has(priority)) {
    filters.push(eq(complaintsTable.priority, priority));
  }
  if (department?.trim()) {
    filters.push(eq(complaintsTable.department, department.trim()));
  }

  const complaints = await db
    .select()
    .from(complaintsTable)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(complaintsTable.createdAt));

  res.json(ListComplaintsResponse.parse(complaints));
});

router.post("/complaints", async (req, res): Promise<void> => {
  const parsed = CreateComplaintBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [complaint] = await db
    .insert(complaintsTable)
    .values({
      ...parsed.data,
      category: parsed.data.category,
      priority: parsed.data.priority,
    })
    .returning();

  res.status(201).json(GetComplaintResponse.parse(complaint));
});

router.get("/complaints/:id", async (req, res): Promise<void> => {
  const params = GetComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [complaint] = await db
    .select()
    .from(complaintsTable)
    .where(eq(complaintsTable.complaintId, params.data.id));

  if (!complaint) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  res.json(GetComplaintResponse.parse(complaint));
});

router.patch("/complaints/:id", async (req, res): Promise<void> => {
  const params = UpdateComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateComplaintBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const update = {
    ...parsed.data,
    assignedStaff: cleanNullable(parsed.data.assignedStaff),
    resolutionRemarks: cleanNullable(parsed.data.resolutionRemarks),
    updatedAt: new Date(),
  };

  const [complaint] = await db
    .update(complaintsTable)
    .set(update)
    .where(eq(complaintsTable.complaintId, params.data.id))
    .returning();

  if (!complaint) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  res.json(UpdateComplaintResponse.parse(complaint));
});

router.delete("/complaints/:id", async (req, res): Promise<void> => {
  const params = DeleteComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [complaint] = await db
    .delete(complaintsTable)
    .where(eq(complaintsTable.complaintId, params.data.id))
    .returning();

  if (!complaint) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;