import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const complaintCategories = [
  "Electrical",
  "Plumbing",
  "Internet/Network",
  "Classroom",
  "Laboratory",
  "Hostel",
  "Cleaning",
  "Other",
] as const;

export const complaintPriorities = ["Low", "Medium", "High", "Urgent"] as const;

export const complaintStatuses = [
  "Pending",
  "In Progress",
  "Resolved",
  "Rejected",
] as const;

export const complaintsTable = pgTable("complaints", {
  complaintId: serial("complaint_id").primaryKey(),
  studentName: varchar("student_name", { length: 120 }).notNull(),
  studentId: varchar("student_id", { length: 40 }).notNull(),
  department: varchar("department", { length: 120 }).notNull(),
  category: varchar("category", { length: 40 }).notNull(),
  location: varchar("location", { length: 160 }).notNull(),
  description: text("description").notNull(),
  priority: varchar("priority", { length: 20 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("Pending"),
  assignedStaff: varchar("assigned_staff", { length: 120 }),
  resolutionRemarks: text("resolution_remarks"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertComplaintSchema = createInsertSchema(complaintsTable)
  .omit({ complaintId: true, status: true, createdAt: true, updatedAt: true })
  .extend({
    category: z.enum(complaintCategories),
    priority: z.enum(complaintPriorities),
    studentName: z.string().trim().min(2),
    studentId: z.string().trim().min(2),
    department: z.string().trim().min(2),
    location: z.string().trim().min(2),
    description: z.string().trim().min(10),
  });

export type InsertComplaint = z.infer<typeof insertComplaintSchema>;
export type Complaint = typeof complaintsTable.$inferSelect;