import { useState } from 'react';
import { Link } from 'wouter';
import { CheckCircle2, ShieldCheck } from 'lucide-react';
import { useCreateComplaint, getListComplaintsQueryKey, getGetComplaintSummaryQueryKey } from '@workspace/api-client-react';
import type { ComplaintInput } from '@workspace/api-client-react';
import { ComplaintForm } from '@/components/complaint-form';
import { BackLink, ErrorState, PageHeading } from '@/components/ui-pieces';
import { getErrorMessage } from '@/lib/complaints';
import { useQueryClient } from '@tanstack/react-query';

export default function NewComplaint() {
  const queryClient = useQueryClient();
  const createMutation = useCreateComplaint();
  const [submittedId, setSubmittedId] = useState<number | null>(null);

  function submit(values: ComplaintInput) {
    createMutation.mutate({ data: values }, {
      onSuccess: (complaint) => {
        setSubmittedId(complaint.complaintId);
        void queryClient.invalidateQueries({ queryKey: getListComplaintsQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetComplaintSummaryQueryKey() });
      },
    });
  }

  if (submittedId) {
    return (
      <div className="mx-auto max-w-[720px] py-8 md:py-14">
        <div className="rounded-3xl border border-emerald-200 bg-emerald-50 p-7 text-center md:p-12" data-testid="state-submitted">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-emerald-100 text-emerald-700"><CheckCircle2 size={32} /></span>
          <p className="mt-6 font-mono-app text-[10px] font-bold uppercase tracking-[0.17em] text-emerald-700">Report received</p>
          <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight text-emerald-950">Thanks for speaking up.</h1>
          <p className="mx-auto mt-4 max-w-md text-sm leading-6 text-emerald-900/70">Your complaint <strong>#{String(submittedId).padStart(3, '0')}</strong> is now in the campus service desk queue. You can follow its progress any time.</p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Link href={`/complaints/${submittedId}`} className="rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground" data-testid="link-view-submitted">View complaint</Link>
            <Link href="/complaints" className="rounded-xl border border-emerald-200 bg-white px-5 py-3 text-sm font-bold text-emerald-800" data-testid="link-back-register">Back to register</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[920px]">
      <BackLink href="/complaints">Back to complaint register</BackLink>
      <PageHeading eyebrow="New complaint" title="Tell us what needs attention." description="It takes about two minutes. Include the exact location and what you observed so the right team can respond." />
      {createMutation.isError && <div className="mb-6"><ErrorState message={getErrorMessage(createMutation.error)} /></div>}
      <ComplaintForm mode="create" onSubmit={(values) => submit(values as ComplaintInput)} isPending={createMutation.isPending} />
      <div className="mt-7 flex items-start gap-3 rounded-2xl border border-border bg-card px-5 py-4 text-xs leading-5 text-muted-foreground"><ShieldCheck size={17} className="mt-0.5 shrink-0 text-accent-foreground" /><p>Your details are used only to follow up on this complaint and help campus teams resolve it responsibly.</p></div>
    </div>
  );
}